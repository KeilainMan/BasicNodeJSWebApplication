# BasicNodeJSWebApplication
 
## Task

Create a basic Node.js web application that serves a static HTML page and handles a form submission using the Express.js framework.
The form should include at least two input fields.



